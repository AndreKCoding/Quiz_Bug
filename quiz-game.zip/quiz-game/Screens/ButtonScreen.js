import React, { Component } from 'react';   /*Variavel React*/
import { Button, View, Text, TouchableOpacity, StyleSheet } from 'react-native';

import RedButton from '../components/RedButton'
import Title from '../components/Title'

export default class App extends Component {
  render() {
    return(
      <View>
        <Title/>
        <RedButton color = {this.props.navigation.getParam('color')}/>
      </View>
    );
  }
}