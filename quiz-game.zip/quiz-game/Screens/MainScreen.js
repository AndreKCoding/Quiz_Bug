import React, { Component } from 'react';   /*Variavel React*/
import { Button, View, Text, TouchableOpacity, StyleSheet } from 'react-native';

import Title from '../components/Title'

export default class MainScreen extends React.Component {
  render() {

    goButtonScreen=(buttonColor)=>{
      this.props.navigation.navigate("ButtonScreen", {color:buttonColor})
    }

    return (
      <View>
        <Title/>

        <TouchableOpacity style={[styles.button, {backgroundColor: 'red'}]} onPress={()=>this.goButtonScreen("red")}>
          <Text style = {styles.text}> Time Vermelho </Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.button, {backgroundColor: 'blue'}]} onPress={()=>this.goButtonScreen("blue")}>
          <Text style = {styles.text}> Time Azul </Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.button, {backgroundColor: 'green'}]} onPress={()=>this.goButtonScreen("green")}>
          <Text style = {styles.text}> Time Verde </Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.button, {backgroundColor: 'yellow'}]} onPress={()=>this.goButtonScreen("yellow")}>
          <Text style = {styles.text}> Time Amarelo </Text>
        </TouchableOpacity>
      </View>
    );
  }
}


const styles = StyleSheet.create({
  button: {
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    borderRadius: 20,
    marginTop: 30,
    width: 200,
    height: 50,
  },
  text: {
    color: 'white',
    textAlign: 'center',
    fontWeight: "bold",
    fontSize: 20
  }
})