import React, { Component } from 'react';   /*Variavel React*/
import { Button, View, Text, TouchableOpacity, StyleSheet } from 'react-native';  /*Elementos inseridos*/
import database from "../Database"

/*Classe que define o Botao*/
class RedButton extends Component {
/*'Component' é a classe usada para acionar os elementos principais para fazer um site*/

  displayAlert() {  /*Funçao para criar o alerta*/
    alert('Você Pressionou o botão!') /*Mostra o alerta*/
  }

buttonPressed(buttonColor) {
  var time = new Data().getTime();
  var query = db.ref('Equipes/' + buttonColor + '/').update(
    
  )
}

  render() {  /*Desenha os objetos*/
    return (  /*Retorna o valor no final*/
      <TouchableOpacity title='Clique em mim' onPress = {this.displayAlert}  
      /*Component que cria um botão manipulavel*/
      /*Estilo do botão*/
        style = {[style.button, {backgroundColor:this.props.color}]}>
        <Text style = {style.textButton}>Clique em Mim</Text>
      </TouchableOpacity>
      /*Define o Botao*/
      /*Para se referir ao componente botao deve se usar 'this'*/
    );
  }
}

/*Estilo do botão*/
const style = StyleSheet.create (
  {
    button: {
      borderRadius: 100, 
      backgroundColor: "red", 
      width: 200, height: 200, 
      textAlign: "center", 
      paddingTop:85, 
      marginLeft: 80,
      marginTop:130
    },
    textButton: {
      color: "white", 
      fontWeight: "bold",
      fontSize: 25
    }
  }
)

export default RedButton;