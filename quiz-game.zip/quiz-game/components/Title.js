import React, { Component } from 'react';   /*Variavel React*/
import { Button, View, Text, TouchableOpacity, StyleSheet } from 'react-native';  /*Elementos inseridos*/

class Title extends Component {
  render() {
    return(
      <Text style = {style.button}>Jogo de Perguntas</Text>
    );
  }
}

const style = StyleSheet.create (
  {
    button: {
      textAlign: "center",
      fontWeight: 'bold',
      backgroundColor: "blue",
      fontSize: 25,
      color: "white"
    }
  }
)

export default Title;