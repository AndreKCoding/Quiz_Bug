import React, { Component } from 'react';   /*Variavel React*/
import { Button, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import MainScreen from "./Screens/MainScreen";
import ButtonScreen from "./Screens/ButtonScreen";

import RedButton from './components/RedButton'
import Title from './components/Title'

import { createAppContainer, createSwitchNavigator } from 'react-navigation'



export default function App() {
  return (
    <View>
      <AppContainer/>
    </View>
  );
}

var AppNavigator = createSwitchNavigator ({
  MainScreen: MainScreen,
  ButtonScreen: ButtonScreen
})

const AppContainer = createAppContainer (AppNavigator)