import { initializeApp } from "firebase";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA07EYrmk00OhJMbL20V0ZrzBf91NFzOUs",
  authDomain: "quiz-e4662.firebaseapp.com",
  databaseURL: "https://quiz-e4662-default-rtdb.firebaseio.com",
  projectId: "quiz-e4662",
  storageBucket: "quiz-e4662.appspot.com",
  messagingSenderId: "89609042907",
  appId: "1:89609042907:web:6635f77432f84c663f45fe"
};

const app = initializeApp(firebaseConfig);